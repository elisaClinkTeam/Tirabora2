# Tirabora Immobiliare – bozza del sito

Prototipo navigabile del nuovo sito di Tirabora Immobiliare (Trieste).
Tutto il sito è in un unico file: apri `index.html` nel browser.

## Revisione 18 (12 novembre 2026)

- Intro: il vento di bora compone il logo, con payoff e indicatore live (Trieste, ora, bora in km/h, dato dimostrativo); suono della bora solo durante l'intro; pulsante "Salta l'intro".
- Ricerca in home in linguaggio naturale ("Descrivi la tua casa dei sogni…"): la frase viene tradotta in filtri e mostra gli immobili compatibili. Vendita e Affitti restano a filtri.
- La barra nell'hero sparisce con l'hero allo scroll e ricompare nella sezione sotto.
- Motion graphic Tirabora a metà homepage.
- My Tirabora: indicatore del vento sotto il titolo.
- Pulsanti e call to action più evidenti e allineati.

Note: il suono del vento proviene dal progetto Moodist (licenza Pixabay o CC0, da verificare prima della pubblicazione). La velocità del vento è un dato dimostrativo.
